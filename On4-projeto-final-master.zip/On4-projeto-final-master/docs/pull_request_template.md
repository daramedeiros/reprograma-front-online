## Entrega M-de-Maravilhosa 

  Parabéns por te chego até aqui ! Estamos quase no final, só falta esse PR e para isso vamos garantir que preenchemos todos os requisitos ?
- [ ] Tem o mínimo de duas seções
- [ ] Página responsiva
- [ ] Tem no mínimo um eventListener

E lembrem, caso precisem de ajuda ou tirar alguma dúvida podem abrir uma issue ou chamar no whats :heart: 


Sobre páginas responsivas:
- https://tableless.com.br/design-responsivo-na-pratica-2-layout-ao-html/

Sobre eventListeners: 
- https://github.com/reprograma/On4-javascript
- metodo addEventListener() (https://www.w3schools.com/jsref/met_element_addeventlistener.asp)
- eventos jQuery (https://www.w3schools.com/jquery/jquery_ref_events.asp)
- Lista de Eventos (https://developer.mozilla.org/en-US/docs/Web/Events)
